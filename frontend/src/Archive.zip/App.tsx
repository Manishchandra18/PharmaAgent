// frontend/src/App.tsx
import { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { SummaryGenerator } from './components/SummaryGenerator';
// --- 1. Import the new ChatWindow component ---
import { ChatWindow } from './components/ChatWindow';

function App() {
  // ... all the state and handlers are unchanged ...
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleUploadSuccess = (text: string) => { setExtractedText(text); setError(null); };
  const handleProcessing = (processing: boolean) => { setIsLoading(processing); };
  const handleError = (errorMessage: string) => { setError(errorMessage); setIsLoading(false); };
  const handleReset = () => { setExtractedText(null); setError(null); };

  return (
    <div className="bg-slate-900 min-h-screen text-white font-sans">
      <main className="container mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-sky-400">CK Birla Medical AI Agent</h1>
          <p className="mt-4 text-lg text-slate-300">Upload patient reports to generate a discharge summary and chat with the AI.</p>
        </header>

        <div className="max-w-4xl mx-auto">
          {!extractedText && ( <FileUpload onUploadSuccess={handleUploadSuccess} onProcessing={handleProcessing} onError={handleError} isLoading={isLoading}/> )}
          {error && <div className="mt-4 text-center text-red-400 bg-red-900/50 p-4 rounded-lg">{error}</div>}
          
          {extractedText && (
            <div className="space-y-8">
              <div className="text-center">
                <button onClick={handleReset} className="bg-slate-600 hover:bg-slate-500 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                  Start Over with New Files
                </button>
              </div>
              
              <SummaryGenerator context={extractedText} />

              {/* --- 2. Replace the placeholder with the ChatWindow component --- */}
              <ChatWindow context={extractedText} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
