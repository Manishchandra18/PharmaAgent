// frontend/src/components/ChatWindow.tsx

import { useState, useRef, useEffect } from 'react';
// frontend/src/components/ChatWindow.tsx

// CORRECT: Add LoaderCircle to the import list
import { SendHorizonal, Bot, User, CornerDownLeft, LoaderCircle } from 'lucide-react';

import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Define the structure of a message
interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatWindowProps {
  context: string; // The extracted text from PDFs
}

export function ChatWindow({ context }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the bottom of the messages list when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:8000/api/v1/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context, messages: newMessages }),
      });

      if (!response.ok || !response.body) {
        throw new Error(`Error: ${response.statusText}`);
      }

      // Add a placeholder for the assistant's message
      setMessages(prev => [...prev, { role: 'assistant', content: '' }]);
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      // Process the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        setMessages(prev => {
          const lastMessage = prev[prev.length - 1];
          lastMessage.content += chunk;
          return [...prev.slice(0, -1), lastMessage];
        });
      }
    } catch (error) {
      console.error("Failed to send message:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-4 sm:p-6 rounded-xl shadow-lg flex flex-col h-[70vh]">
      <h2 className="text-2xl font-bold text-sky-300 mb-4 border-b border-slate-700 pb-3">Chat with AI</h2>
      
      {/* Message Display Area */}
      <div className="flex-grow overflow-y-auto pr-2 space-y-6">
        {messages.map((msg, index) => (
          <div key={index} className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
            {msg.role === 'assistant' && <div className="flex-shrink-0 w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center"><Bot size={20} /></div>}
            <div className={`max-w-xl p-3 rounded-lg ${msg.role === 'user' ? 'bg-sky-800' : 'bg-slate-700'} prose prose-invert prose-sm`}>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {msg.content}
            </ReactMarkdown>
            </div>
            {msg.role === 'user' && <div className="flex-shrink-0 w-8 h-8 bg-slate-600 rounded-full flex items-center justify-center"><User size={20} /></div>}
          </div>
        ))}
        {isLoading && messages[messages.length-1]?.role === 'user' && (
          <div className="flex items-start gap-3">
             <div className="flex-shrink-0 w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center"><Bot size={20} /></div>
             <div className="p-3 bg-slate-700 rounded-lg"><span className="animate-pulse">Thinking...</span></div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="mt-6 flex items-center gap-3 border-t border-slate-700 pt-4">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
          placeholder="Ask a question about the documents..."
          className="flex-grow bg-slate-700 rounded-lg p-3 resize-none focus:ring-2 focus:ring-sky-500 focus:outline-none"
          rows={1}
          disabled={isLoading}
        />
        <button
          onClick={handleSendMessage}
          disabled={isLoading || !input.trim()}
          className="bg-sky-600 hover:bg-sky-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold p-3 rounded-lg transition-colors"
          aria-label="Send message"
        >
          {isLoading ? <LoaderCircle className="animate-spin" size={20} /> : <SendHorizonal size={20} />}
        </button>
      </div>
    </div>
  );
}
