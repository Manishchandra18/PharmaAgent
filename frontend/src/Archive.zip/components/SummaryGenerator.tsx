// frontend/src/components/SummaryGenerator.tsx

import { useState } from "react";
import { Sparkles, Download, LoaderCircle } from "lucide-react";

interface SummaryGeneratorProps {
  context: string; // The extracted text from the PDFs
}

export function SummaryGenerator({ context }: SummaryGeneratorProps) {
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateSummary = async () => {
    setIsLoading(true);
    setError(null);
    setSummary(null);

    try {
      const response = await fetch('http://localhost:8000/api/v1/generate-summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ context: context }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || "Failed to generate summary");
      }

      const data = await response.json();
      setSummary(data.summary);

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadSummary = () => {
    if (!summary) return;

    const blob = new Blob([summary], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'discharge_summary.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl shadow-lg">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-sky-300 mb-4 sm:mb-0">Discharge Summary</h2>
        <button
          onClick={handleGenerateSummary}
          disabled={isLoading}
          className="w-full sm:w-auto bg-sky-600 hover:bg-sky-500 disabled:bg-sky-800 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center"
        >
          {isLoading ? (
            <LoaderCircle className="animate-spin mr-2" />
          ) : (
            <Sparkles className="mr-2 h-5 w-5" />
          )}
          {summary ? "Regenerate Summary" : "Generate Summary"}
        </button>
      </div>

      {error && <div className="my-4 text-center text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</div>}

      {/* Summary Display Area */}
      {summary && (
        <div className="mt-4 p-4 bg-slate-900/70 rounded-lg">
          {/* Using 'pre-wrap' preserves whitespace and line breaks from the AI's response */}
          <pre className="text-slate-200 whitespace-pre-wrap font-sans">{summary}</pre>
          <div className="text-right mt-4">
            <button
              onClick={handleDownloadSummary}
              className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center ml-auto"
            >
              <Download className="mr-2 h-5 w-5" />
              Download Summary
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
