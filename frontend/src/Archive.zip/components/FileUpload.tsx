// frontend/src/components/FileUpload.tsx

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, FileText, X, LoaderCircle } from 'lucide-react';

// Props interface for communication with App.tsx
interface FileUploadProps {
  onUploadSuccess: (extractedText: string) => void;
  onProcessing: (isProcessing: boolean) => void;
  onError: (errorMessage: string) => void;
  isLoading: boolean;
}

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export function FileUpload({ onUploadSuccess, onProcessing, onError, isLoading }: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(prevFiles => [...prevFiles, ...acceptedFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    disabled: isLoading, // Disable dropzone while loading
  });

  const removeFile = (fileName: string) => {
    setFiles(files.filter(file => file.name !== fileName));
  };
  
  // --- NEW: Function to handle the file upload ---
  const handleProcessFiles = async () => {
    if (files.length === 0) {
      onError("Please select at least one file to process.");
      return;
    }
    onProcessing(true);
    onError(""); // Clear previous errors

    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    try {
      const response = await fetch('http://localhost:8000/api/v1/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'An unknown error occurred.');
      }

      const data = await response.json();
      onUploadSuccess(data.extracted_text);

    } catch (error) {
      if (error instanceof Error) {
        onError(`Upload failed: ${error.message}`);
      } else {
        onError("An unexpected error occurred during upload.");
      }
    } finally {
      onProcessing(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        {...getRootProps()}
        className={`p-10 border-2 border-dashed rounded-xl text-center transition-colors duration-300
          ${isDragActive ? 'border-sky-400 bg-sky-900/30' : 'border-slate-600'}
          ${isLoading ? 'cursor-not-allowed bg-slate-800/50' : 'cursor-pointer hover:border-sky-500 hover:bg-slate-800/20'}
        `}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center justify-center text-slate-400">
          <UploadCloud className="w-12 h-12 mb-4" />
          {isDragActive ? (
            <p className="text-lg font-semibold text-sky-300">Drop the files here...</p>
          ) : (
            <>
              <p className="text-lg font-semibold">Drag & drop PDF reports here</p>
              <p className="text-sm mt-1">or click to select files</p>
            </>
          )}
        </div>
      </div>

      {files.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold text-white mb-4">Selected Files</h3>
          <ul className="space-y-3">
            {files.map((file, index) => (
              <li key={index} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                <div className="flex items-center space-x-3"><FileText className="w-6 h-6 text-sky-400" /><span>{file.name}</span></div>
                <div className="flex items-center space-x-4"><span className="text-sm text-slate-400">{formatFileSize(file.size)}</span>
                  <button onClick={() => removeFile(file.name)} disabled={isLoading} className="p-1 text-slate-500 hover:text-red-500 disabled:opacity-50"><X className="w-5 h-5" /></button>
                </div>
              </li>
            ))}
          </ul>
          
          {/* --- NEW: Process Files Button --- */}
          <div className="mt-8 text-center">
            <button 
              onClick={handleProcessFiles} 
              disabled={isLoading}
              className="w-full md:w-auto bg-sky-600 hover:bg-sky-500 disabled:bg-sky-800 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg transition-colors flex items-center justify-center mx-auto"
            >
              {isLoading ? (
                <>
                  <LoaderCircle className="animate-spin mr-2" />
                  Processing...
                </>
              ) : "Process Files & Begin"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
